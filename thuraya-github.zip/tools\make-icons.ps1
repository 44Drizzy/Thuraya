# Draws the Thuraya app icons (crescent, rising bars, gold stars on navy) as PNG files.
# Usage: powershell -ExecutionPolicy Bypass -File make-icons.ps1
Add-Type -AssemblyName System.Drawing
$out = Join-Path (Split-Path $PSScriptRoot -Parent) "icons"
New-Item -ItemType Directory -Force $out | Out-Null

function New-Star([float]$cx, [float]$cy, [float]$r) {
  $k = $r * 0.26
  $pts = @(
    (New-Object System.Drawing.PointF($cx, ($cy - $r))),
    (New-Object System.Drawing.PointF(($cx + $k), ($cy - $k))),
    (New-Object System.Drawing.PointF(($cx + $r), $cy)),
    (New-Object System.Drawing.PointF(($cx + $k), ($cy + $k))),
    (New-Object System.Drawing.PointF($cx, ($cy + $r))),
    (New-Object System.Drawing.PointF(($cx - $k), ($cy + $k))),
    (New-Object System.Drawing.PointF(($cx - $r), $cy)),
    (New-Object System.Drawing.PointF(($cx - $k), ($cy - $k)))
  )
  return ,$pts
}

function Draw-Icon([int]$size, [float]$logoFrac, [string]$file) {
  $bmp = New-Object System.Drawing.Bitmap($size, $size)
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.PixelOffsetMode = [System.Drawing.Drawing2D.PixelOffsetMode]::HighQuality

  # Navy background with a soft diagonal gradient
  $bgRect = New-Object System.Drawing.Rectangle(0, 0, $size, $size)
  $bg = New-Object System.Drawing.Drawing2D.LinearGradientBrush($bgRect, [System.Drawing.Color]::FromArgb(12,47,53), [System.Drawing.Color]::FromArgb(26,76,82), 45)
  $g.FillRectangle($bg, $bgRect)

  # Map the 64-unit logo space into a centered square
  $box = $size * $logoFrac
  $s = $box / 54.0
  $ox = ($size - $box) / 2 - 4 * $s
  $oy = ($size - $box) / 2 - 4 * $s
  $g.TranslateTransform($ox, $oy)
  $g.ScaleTransform($s, $s)

  # Crescent: big circle minus offset circle
  $outer = New-Object System.Drawing.Drawing2D.GraphicsPath
  $outer.AddEllipse(5, 9, 50, 50)
  $cut = New-Object System.Drawing.Drawing2D.GraphicsPath
  $cut.AddEllipse(18, 3, 44, 44)
  $region = New-Object System.Drawing.Region($outer)
  $region.Exclude($cut)
  $g.FillRegion([System.Drawing.Brushes]::White, $region)

  # Rising bars (teal gradient)
  $teal1 = [System.Drawing.Color]::FromArgb(31,138,133)
  $teal2 = [System.Drawing.Color]::FromArgb(60,194,184)
  foreach ($b in @(@(27,40,12), @(35,33,19), @(43,25,27))) {
    $r = New-Object System.Drawing.RectangleF($b[0], $b[1], 6, $b[2])
    $br = New-Object System.Drawing.Drawing2D.LinearGradientBrush($r, $teal2, $teal1, 90)
    $g.FillRectangle($br, $r)
    $br.Dispose()
  }

  # Teal swoosh under the bars (quadratic curve as a cubic Bezier)
  $pen = New-Object System.Drawing.Pen($teal2, 3)
  $pen.StartCap = [System.Drawing.Drawing2D.LineCap]::Round
  $pen.EndCap = [System.Drawing.Drawing2D.LineCap]::Round
  $g.DrawBezier($pen, 22, 50, 34, 55.33, 46, 48.67, 58, 30)

  # Gold stars and the dotted path between them
  $gold = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::FromArgb(212,162,58))
  $dash = New-Object System.Drawing.Pen([System.Drawing.Color]::FromArgb(212,162,58), 1)
  $dash.DashPattern = @(2, 2)
  $g.DrawLines($dash, @((New-Object System.Drawing.PointF(26,26.5)), (New-Object System.Drawing.PointF(36,18)), (New-Object System.Drawing.PointF(51,10.5))))
  $g.FillPolygon($gold, (New-Star 26 27.6 3.6))
  $g.FillPolygon($gold, (New-Star 36 18.4 3.4))
  $g.FillPolygon($gold, (New-Star 51 10.6 5.6))

  $g.Dispose()
  $bmp.Save((Join-Path $out $file), [System.Drawing.Imaging.ImageFormat]::Png)
  $bmp.Dispose()
  Write-Output "Wrote $file"
}

Draw-Icon 192 0.70 "icon-192.png"
Draw-Icon 512 0.70 "icon-512.png"
Draw-Icon 512 0.56 "icon-maskable-512.png"
Draw-Icon 180 0.68 "apple-touch-icon.png"
Draw-Icon 32  0.80 "favicon-32.png"
