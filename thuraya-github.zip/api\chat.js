// Ask Thuraya: live answers from Claude on your Vercel site.
//
// The API key never reaches the browser: set ANTHROPIC_API_KEY in
// Vercel -> Project -> Settings -> Environment Variables, then redeploy.
// Without a key this returns 503 and the app falls back to its built-in answers.
//
// The instructions live here on the server, so the page can't be used to send
// Claude arbitrary prompts: it only sends the language, a summary of the user's
// numbers, and the last few chat messages.

import Anthropic from "@anthropic-ai/sdk";

const MODEL = "claude-opus-5-5";
const MAX_MESSAGES = 12;
const MAX_MESSAGE_CHARS = 1500;
const MAX_CONTEXT_CHARS = 20000;

function instructions(lang, context) {
  const langRule =
    lang === "ar"
      ? "Reply in Kuwaiti Arabic dialect (اللهجة الكويتية), friendly and clear. Write amounts like 150 د.ك."
      : "Reply in English. Write amounts like KD 150.";
  return `You are Thuraya (ثريا), the money helper inside the Thuraya budgeting app in Kuwait. ${langRule}
Talk like a warm, sensible friend who is good with money, not like a bot. Answer in one to three short sentences of plain text, using the user's real numbers below. No bullet points, lists, headings, bold or emoji unless the user asks for a breakdown. Never call yourself an AI, an assistant or a language model, and don't open with filler like "Great question".
Help with budgeting, spending habits, bills, saving goals and warranties. Politely steer anything unrelated to the user's money back to their finances.
If asked whether they can afford to invest (for example in gold or Kuwaiti stocks on Boursa Kuwait), answer from investReadiness: say how much is free now and per month without touching bills or the safety net, and whether a requested amount fits. Never recommend specific stocks, companies, funds or crypto and never predict prices; add one short sentence that you can't say what to buy and a licensed advisor can help with that.
If the data can't answer the question, say so plainly and what you'd need.

USER DATA (JSON):
${context}`;
}

function cleanMessages(raw) {
  if (!Array.isArray(raw)) return [];
  const messages = raw
    .filter(
      (m) =>
        m &&
        (m.role === "user" || m.role === "assistant") &&
        typeof m.content === "string" &&
        m.content.trim(),
    )
    .slice(-MAX_MESSAGES)
    .map((m) => ({ role: m.role, content: m.content.slice(0, MAX_MESSAGE_CHARS) }));
  while (messages.length && messages[0].role !== "user") messages.shift();
  return messages;
}

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    res.status(405).json({ error: "method_not_allowed" });
    return;
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    res.status(503).json({ error: "not_configured" });
    return;
  }

  const body = typeof req.body === "string" ? safeParse(req.body) : req.body || {};
  const lang = body.lang === "ar" ? "ar" : "en";
  const context = typeof body.context === "string" ? body.context.slice(0, MAX_CONTEXT_CHARS) : "{}";
  const messages = cleanMessages(body.messages);
  if (!messages.length || messages[messages.length - 1].role !== "user") {
    res.status(400).json({ error: "bad_request" });
    return;
  }

  const client = new Anthropic(); // reads ANTHROPIC_API_KEY

  try {
    const response = await client.beta.messages.create({
      model: MODEL,
      max_tokens: 4096,
      // Short, conversational replies: low effort keeps them quick and cheap.
      output_config: { effort: "low" },
      // If a safety check declines the request, the API retries it on a suitable model.
      betas: ["server-side-fallback-2026-07-01"],
      fallbacks: "default",
      system: instructions(lang, context),
      messages,
    });

    if (response.stop_reason === "refusal") {
      res.status(200).json({ text: null, refused: true });
      return;
    }
    const text = response.content
      .filter((block) => block.type === "text")
      .map((block) => block.text)
      .join("")
      .trim();
    res.status(200).json({ text });
  } catch (error) {
    if (error instanceof Anthropic.AuthenticationError) {
      console.error("Anthropic API key is invalid");
      res.status(503).json({ error: "not_configured" });
    } else if (error instanceof Anthropic.RateLimitError) {
      res.status(429).json({ error: "rate_limited" });
    } else if (error instanceof Anthropic.BadRequestError) {
      console.error("Bad request:", error.message);
      res.status(502).json({ error: "bad_upstream_request" });
    } else if (error instanceof Anthropic.APIError) {
      console.error(`Anthropic API error ${error.status}:`, error.message);
      res.status(502).json({ error: "upstream_error" });
    } else {
      console.error(error);
      res.status(500).json({ error: "server_error" });
    }
  }
}

function safeParse(text) {
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}
