<p align="center">
  <img src="icons/icon-192.png" width="96" alt="Thuraya logo">
</p>

<h1 align="center">Thuraya ثريا</h1>
<p align="center"><b>Your money, made clearer</b><br>
A mobile app prototype that helps people in Kuwait manage spending, save for goals, never miss a bill and keep their receipts in one place.</p>

---

## About

Thuraya (ثريا, "the stars") is an AI-powered personal finance assistant built for the Kuwaiti market. It turns everyday banking data into clear guidance: where the money goes, what is safe to spend, which bills are coming up, and how to reach savings goals. It works in **English and Kuwaiti Arabic**.

This repository is an interactive **prototype / MVP**. It runs entirely in the browser, can be installed on a phone's home screen like a native app, and opens with example data for a sample user ("Sara").

## Features

| Area | What it does |
|---|---|
| **Home dashboard** | Monthly budget ring, bank-sync badge, quick tiles and upcoming bills |
| **Rest of the month** | Safe-to-spend per day, after the bills still due before month end |
| **Financial health score** | A 0–100 score from spending pace, on-time bills, saving rate and emergency fund |
| **Budget** | Essential vs optional split, spending by category, 6-month trend chart, end-of-month forecast (Premium) |
| **Goals** | Savings goals with progress and a personal monthly plan ("Save KD 70 per month to reach it by Jan") |
| **Reminders** | Bills, installments and school fees, with "Mark paid" that logs the expense and rolls to next month |
| **Pay-later apps** | Link **Tabby** and **Deema** for installment reminders only. Payments stay in those apps. |
| **Receipts & warranties** | Store receipts with photos and get alerts before a warranty expires |
| **School expenses** | School category, back-to-school savings goal, school-fee reminders |
| **Invest (gold & Kuwaiti stocks)** | Readiness check: how much is free to invest without touching bills or a 3-month safety net, gold prices per gram (24K/22K/21K) and the Boursa Kuwait Premier index (example prices). It checks affordability only and never recommends what to buy. |
| **Ask Thuraya** | Chat assistant that answers from the user's own numbers ("Can I afford a trip next month?", "Do I have enough to invest KD 300 in stocks?") |
| **Suggestions & complaints** | Feedback form in Profile that opens an email to thuraya.kw@outlook.com, plus a Find us section |
| **Plans** | Basic (free) and Premium (KD 3 / month or KD 20 / year) |
| **Bilingual** | Full English / Arabic switch with right-to-left layout |
| **Installable** | Opens full-screen from the home screen and works offline after the first visit |

## Run it

There is no build step. Open `index.html` in a browser.

For the home-screen install and offline mode, serve it over a local web server or HTTPS. For example, with VS Code's *Live Server* extension, or:

```bash
npx serve .
```

## Publish with GitHub Pages

1. Push this folder to a GitHub repository, or upload the files with **Add file → Upload files**.
2. Go to **Settings → Pages**.
3. Under **Build and deployment**, set **Source** to *Deploy from a branch*. Choose `main` and `/ (root)`, then **Save**.
4. After a minute or two, the app is live at `https://<your-username>.github.io/<repository-name>/`.

## Install on a phone

- **iPhone (Safari):** open the link, tap **Share**, then **Add to Home Screen**.
- **Android (Chrome):** open the link, tap **⋮**, then **Install app** / **Add to Home screen**.

## Project structure

```
├── index.html             The whole app: layout, styles, logic, English/Arabic text
├── api/chat.js            Vercel server function: live Ask Thuraya answers from Claude
├── package.json           Tells Vercel to install the Anthropic SDK for api/chat.js
├── manifest.webmanifest   App name, icons, colors, full-screen mode
├── sw.js                  Service worker for offline use
├── icons/                 Home-screen icons and favicon
└── tools/make-icons.ps1   Regenerates the icons (Windows PowerShell)
```

## Turn on live AI answers (Vercel)

Ask Thuraya works without any setup, using built-in answers for common questions. For real AI answers to any question:

1. Create an API key at **console.anthropic.com** → **API Keys**. Add a payment method and set a **monthly spend limit** under **Billing**, so costs can't run away.
2. In **Vercel**, open the project → **Settings → Environment Variables** and add:
   - **Key:** `ANTHROPIC_API_KEY`
   - **Value:** your key
3. Go to **Deployments** → **⋯** on the latest one → **Redeploy**.

The key stays on Vercel's server and is never sent to the browser. The instructions Thuraya follows are in `api/chat.js`, so the website can't be used to send the AI arbitrary prompts. If the key is missing or a request fails, the chat quietly falls back to the built-in answers.

### Where things live in `index.html`

| Look for | To change |
|---|---|
| `:root { --navy … }` at the top of `<style>` | Brand colors (navy, teal, gold) for light and dark mode |
| `const L = { en:{…}, ar:{…} }` | All English and Arabic text |
| `const CAT`, `RTYPE`, `RCAT` | Expense categories, reminder types, receipt categories |
| `const BANKS`, `const BNPL` | Linked banks and pay-later apps (Tabby, Deema) |
| `function seed()` | The example data the app opens with |
| `function vHome()`, `vBudget()`, `vGoals()`, … | Each screen |
| `function localAnswer()` | How Ask Thuraya answers questions |

### After changing the app

Change `VERSION` in `sw.js` (for example to `thuraya-v8`) so installed phones download the new version.

## Data and privacy

Everything a user enters is saved only in their own browser (`localStorage`). When live AI answers are turned on, a question sent to Ask Thuraya goes to the `api/chat` function together with a short summary of that user's budget numbers, so the answer can use them; nothing else leaves the browser. Bank, Tabby and Deema linking are simulated in this prototype. The production app would connect through Kuwait's Open Banking framework, with the user's approval.

## Tech

Plain HTML, CSS and JavaScript, with no framework or build tools. Fonts: Inter Tight and IBM Plex Sans Arabic (Google Fonts). It's a Progressive Web App, with a web manifest and a service worker. Live chat answers come from Claude (`claude-opus-5-5`) through a Vercel serverless function using the official Anthropic SDK.

## Roadmap

- Live gold prices and Boursa Kuwait data through a market-data provider
- Real bank connections through Open Banking (NBK, KFH, Boubyan)
- User accounts and cloud sync
- Native iOS and Android apps
